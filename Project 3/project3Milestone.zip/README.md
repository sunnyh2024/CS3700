The high level approach of this router stores routes in a dictionary, where the keys are the source ips and the values are a list of all the routes from that ip. Sending packets is based off of this design, using the template given to us, we first find valid routes with the given dest address. Based on these routes, we then find the best route possible with certain conditions, then use this route to forward the packet, update the routing table, and dump said table. 

The biggest challenge that we faced was the logic of how to implement this kind of design, since having both a list and a dictionary made it difficult to get the desired values at times. 

In order to test our code, we ran the sim with the level 1 test cases in the Khoury Linux Server, and used the error messages to debug.