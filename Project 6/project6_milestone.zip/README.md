<p>Our high-level approach for this project was to use functions to handle messages and requests from replicas and clients. We store this data in global variables.
We initially hold an election to start the while loop with a leader.
Our main while loop then sends all the messages to the handle_all_reqs method, which uses something similar to the command design pattern to send the message to the correct handler function. After this, we check if the replica has timed out, in which case we start an election. Finally, we send a heartbeat if we are the leader, and the loop repeats. </p>

<p>The main challenge that we faced was the election. We found it hard to find a place to start. There were also a lot of global variables to keep track of. For example, when we received a vote request, we had to compare the commits, then respond with a vote and change our current vote and other data to match</p>

<p>We tested our code by running the given tests (simple-1, simple-2, and crash-1 in this case) using the sim file, and debugged it by using print statements at various points in the script to find the lines we had to fix. </p>